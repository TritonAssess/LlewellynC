﻿namespace TritonMVC.DataModel
{
    public class BranchDataModel
    {
        public class BranchMaster
        {
            public int BranchID { get; set; } = 0;
            public string BranchName { get; set; } = string.Empty;

        }
            
    }
}

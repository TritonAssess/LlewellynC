﻿namespace TritonMVC.DataModel
{
    public class VehicleDataModel
    {
        public int VehicleID { get; set; } = 0;
        public string Type { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string VinNumber { get; set; } = string.Empty;
        public string NumberPlate { get; set; } = string.Empty;
        public int BranchID { get; set; } = 0;

    }

    public class VehicleListDataModel : VehicleDataModel
    {
        public string BranchName { get; set; } = string.Empty;
    }
}

﻿namespace TritonMVC.Models
{
    public class VehicleModel
    {
        public int VehicleID { get; set; } = 0;
        public string Type { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string VinNumber { get; set; } = string.Empty;
        public string NumberPlate { get; set; } = string.Empty;

        public int BranchID { get; set; } = 0; 

    }

    public class VehicleListModel : VehicleModel
    {
        public string BranchName { get; set; } = string.Empty;
    }
    public class VehicleTypesModel
    {
        public string Type { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel;
namespace TritonMVC.Models
{
    public class BranchModel
    {   
        [DisplayName("Branch ID")]
        public int BranchID { get; set; } = 0;

        [DisplayName("Name")]
        public string BranchName { get; set; } = string.Empty;
    }
}

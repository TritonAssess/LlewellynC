﻿namespace TritonMVC.Models
{
    public class WaybillModel
    {

        public int WaybillID { get; set; } = 0;
        public decimal TotalWeight { get; set; } = 0;
        public int TotalParcels { get; set; } = 0;
        public int AssignedVehicle { get; set; } = 0;

    }

    public class WaybillListModel : WaybillModel
    {
        public string VehicleDescription { get; set; } = string.Empty;
    }

}

﻿using TritonMVC.DataModel;

namespace TritonMVC.Services
{
    public interface IBranch
    {
        BranchDataModel.BranchMaster GetBranchByID(int ID);
        List<BranchDataModel.BranchMaster> GetBranches();
    }
}
﻿using System.Data.SqlClient;

namespace TritonMVC.Interfaces

{
    public interface IDatabase
    {
        void CloseConnection();
        bool ModifyDatabase(string BaseCommand, List<Services.Parameters> Params);
        SqlDataReader ReadData(string BaseCommand, List<Services.Parameters> Params);
    }
}
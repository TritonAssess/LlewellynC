﻿using TritonMVC.DataModel;

namespace TritonMVC.Services
{
    public interface IWaybill
    {
        WaybillListModel GetWayBillByID(int ID);
        IEnumerable<WaybillListModel> GetWaybills();
        bool Insert(WaybillListModel waybill);
        bool Update(WaybillModel waybill);
    }
}
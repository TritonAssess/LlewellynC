﻿using TritonMVC.DataModel;
using TritonMVC.Models;

namespace TritonMVC.Services
{
    public interface IVehicle
    {
        List<VehicleListDataModel> GetList();
        bool Insert(VehicleDataModel vehicle);
    }
}
﻿using System.Data.SqlClient;
namespace TritonMVC.Services
{
    public class Parameters
    {
        public string ParameterName { get; set; } = string.Empty;
        public string ParameterValue { get; set; } = string.Empty;

    }

    public class Database : Interfaces.IDatabase
    {

        private string ConnectionString = "Server=localhost\\SQLEXPRESS;Database=triton;User Id=webuser;Password=webuser;";

        protected SqlConnection SQLConn;
        public Database()
        {
            this.SQLConn = new SqlConnection(this.ConnectionString);
            try
            {

                this.SQLConn.Open();


            }
            catch (Exception ex)
            {

            }
        }

        public SqlDataReader ReadData(String BaseCommand, List<Parameters> Params)
        {
            try
            {

                SqlCommand Command = new SqlCommand(BaseCommand, this.SQLConn);
                Command.Parameters.Clear();

                //Read the parameters and add as sqlparameters
                foreach (Parameters item in Params)
                {
                    Command.Parameters.Add(new SqlParameter(item.ParameterName, item.ParameterValue));
                }

                SqlDataReader Reader = Command.ExecuteReader();

                return Reader;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {

            }
        }

        public bool ModifyDatabase(string BaseCommand, List<Parameters> Params)
        {
            SqlCommand Command = new SqlCommand(BaseCommand, this.SQLConn);
            Command.Parameters.Clear();
            
            //Read the parameters and add as sqlparameters
            foreach (Parameters item in Params)
            {
                Command.Parameters.Add(new SqlParameter(item.ParameterName, item.ParameterValue));
            }
            try
            {
                Command.ExecuteNonQuery();
                //Command.Transaction.Commit();
            }
            catch (Exception ex)
            {
                //Command.Transaction.Rollback();
            }

            return true;
        }

        public void CloseConnection()
        {
            this.SQLConn.Close();
        }

    }
}

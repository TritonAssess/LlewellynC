﻿using System.Data.SqlClient;
using TritonMVC.DataModel;
using TritonMVC.Interfaces;
using TritonMVC.Services;

namespace TritonMVC.Services
{
    public class Vehicle : IVehicle
    {

        private readonly IDatabase _database;

        public Vehicle(IDatabase Database)
        {
            _database = Database;
        }

        public List<DataModel.VehicleListDataModel> GetList()
        {
            List<DataModel.VehicleListDataModel> vehicles = new List<DataModel.VehicleListDataModel>();

            string baseCommand = @"select vehicle.*,
                                    case when brname is null then 'No Branch' else brname end as brname 
                                    from vehicle left join branch on brid=vhbranchid  ";

            //Create a blank list for the Parameters
            List<Services.Parameters> parameters = new List<Services.Parameters>();


            SqlDataReader reader = _database.ReadData(baseCommand, parameters);

            if (reader.HasRows)
            {

                while (reader.Read())
                {
                    vehicles.Add(new DataModel.VehicleListDataModel()
                    {
                        VehicleID = reader.GetInt32(reader.GetOrdinal("vhid")),
                        Type = reader.GetString(reader.GetOrdinal("vhtype")),
                        Description = reader.GetString(reader.GetOrdinal("vhdescription")),
                        VinNumber = reader.GetString(reader.GetOrdinal("vhvinnumber")),
                        NumberPlate = reader.GetString(reader.GetOrdinal("vhnumberplate")),
                        BranchName = reader.GetString(reader.GetOrdinal("brname"))
                    });
                };

            }

            reader.Close();
            _database.CloseConnection();

            return vehicles;
        }

        public bool Insert(DataModel.VehicleDataModel vehicle)
        {
            string baseCommand = @"INSERT INTO [dbo].[vehicle]
                                ([vhtype]
                                ,[vhdescription]
                                ,[vhvinnumber]
                                ,[vhnumberplate]
                                ,[vhbranchid])
                                 VALUES
                                (@Type
                                ,@Description
                                ,@VinNumber
                                ,@NumberPlate
                                ,@BranchID)";

            List<Parameters> parameters = new List<Parameters>()
            {
                new Parameters
                {
                    ParameterName = "@Type",
                    ParameterValue = vehicle.Type.ToString()
                },
                new Parameters
                {
                    ParameterName = "@Description",
                    ParameterValue = vehicle.Description
                },
                new Parameters
                {
                    ParameterName = "@VinNumber",
                    ParameterValue = vehicle.VinNumber
                },
                new Parameters
                {
                    ParameterName = "@NumberPlate",
                    ParameterValue = vehicle.NumberPlate
                },
                new Parameters
                {
                    ParameterName = "@BranchID",
                    ParameterValue = vehicle.BranchID.ToString()
                }
            };

            _database.ModifyDatabase(baseCommand, parameters);
            _database.CloseConnection();

            return true;
        }

        
    }
}

﻿using TritonMVC.Services;
using TritonMVC.Interfaces;
using System.Data.SqlClient;


namespace TritonMVC.Services
{
    public class Branch : IBranch
    {
        public readonly IDatabase _database;

        public Branch(IDatabase Database)
        {
            _database = Database;
        }

        public List<DataModel.BranchDataModel.BranchMaster> GetBranches()
        {
            List<DataModel.BranchDataModel.BranchMaster> branches = new List<DataModel.BranchDataModel.BranchMaster>();

            string baseCommand = "select * from branch order by brname";

            SqlDataReader reader = _database.ReadData(baseCommand, new List<Services.Parameters>());

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    branches.Add(new DataModel.BranchDataModel.BranchMaster()
                    {
                        BranchID = reader.GetInt32(reader.GetOrdinal("brid")),
                        BranchName = reader.GetString(reader.GetOrdinal("brname"))
                    });
                }
            }
            reader.Close();
            _database.CloseConnection();
            return branches;
        }

        public DataModel.BranchDataModel.BranchMaster GetBranchByID(int ID)
        {
            DataModel.BranchDataModel.BranchMaster branchMaster = new DataModel.BranchDataModel.BranchMaster();

            string baseCommand = "select * from branch where brid=@ID";
            List<Services.Parameters> parameters = new List<Services.Parameters>();
            parameters.Add(new Services.Parameters()
            {
                ParameterName = "@ID",
                ParameterValue = ID.ToString()
            });

            SqlDataReader reader = _database.ReadData(baseCommand, parameters);

            if (reader.HasRows)
            {
                reader.Read();

                branchMaster.BranchID = reader.GetInt32(reader.GetOrdinal("brid"));
                branchMaster.BranchName = reader.GetString(reader.GetOrdinal("brname"));

            }

            reader.Close();
            _database.CloseConnection();

            return branchMaster;
        }

        public bool Insert(DataModel.BranchDataModel.BranchMaster branchData)
        {
            string baseCommand = @"INSERT INTO [dbo].[branch]
                                   ([brname])
                                    VALUES
                                   (@BranchName)";
            List<Parameters> parameters = new List<Parameters>()
            {
                new Parameters
                {
                    ParameterName = "@BranchName",
                    ParameterValue = branchData.BranchName
                }
            };

            _database.ModifyDatabase(baseCommand, parameters);
            _database.CloseConnection();

            return true;
        }
    }
}

﻿using System.Data.SqlClient;
using TritonMVC.Interfaces;

namespace TritonMVC.Services

{
    public class Waybill : IWaybill
    {
        private readonly IDatabase _database;

        public Waybill(IDatabase database)
        {
            _database = database;
        }
        public DataModel.WaybillListModel GetWayBillByID(int ID)
        {
            DataModel.WaybillListModel waybill = new DataModel.WaybillListModel();

            string baseCommand = "select * from waybills where wbid=@ID";
            List<Parameters> parameters = new List<Parameters>()
            {
                new Parameters
                {
                    ParameterName = "@ID",
                    ParameterValue = ID.ToString()
                }
            };

            SqlDataReader reader = _database.ReadData(baseCommand, parameters);

            if (reader.HasRows)
            {
                reader.Read();

                waybill.WaybillID = reader.GetInt32(reader.GetOrdinal("wbid"));
                waybill.TotalWeight = reader.GetDecimal(reader.GetOrdinal("wbtotalweight"));
                waybill.TotalParcels = reader.GetInt32(reader.GetOrdinal("wbtotalparcels"));
                waybill.AssignedVehicle = reader.GetInt32(reader.GetOrdinal("wbassignedvehicle"));

            }

            reader.Close();
            _database.CloseConnection();

            return waybill;

        }
        
        public bool Update(DataModel.WaybillModel waybill)
        {
            string baseCommand = @"update waybills set wbtotalweight=@TotalWeight, 
                                  wbtotalparcels=@TotalParcels,
                                  wbassignedvehicle=@AssignedVehicle 
                                  where wbid=@WaybillID";

            List<Parameters> parameters = new List<Parameters>()
            {
                new Parameters
                {
                    ParameterName = "@TotalWeight",
                    ParameterValue = waybill.TotalWeight.ToString()
                },
                new Parameters
                {
                    ParameterName = "@TotalParcels",
                    ParameterValue = waybill.TotalParcels.ToString()
                },
                new Parameters
                {
                    ParameterName = "@AssignedVehicle",
                    ParameterValue = waybill.AssignedVehicle.ToString()
                },
                new Parameters
                {
                    ParameterName = "@WaybillID",
                    ParameterValue = waybill.WaybillID.ToString()
                }
            };

            _database.ModifyDatabase(baseCommand, parameters);

            _database.CloseConnection();

            return true;
        }
        public bool Insert(DataModel.WaybillListModel waybill)
        {
            string baseCommand = @"insert into waybills (
                                   wbtotalweight,
                                   wbtotalparcels,
                                   wbassignedvehicle)
                                   values (
                                   @TotalWeight,
                                   @TotalParcels,
                                   @AssignedVehicle)";

            List<Parameters> parameters = new List<Parameters>()
            {
                new Parameters
                {
                    ParameterName = "@TotalWeight",
                    ParameterValue = waybill.TotalWeight.ToString()
                },
                new Parameters
                {
                    ParameterName = "@TotalParcels",
                    ParameterValue = waybill.TotalParcels.ToString()
                },
                new Parameters
                {
                    ParameterName = "@AssignedVehicle",
                    ParameterValue = waybill.AssignedVehicle.ToString()
                },
                new Parameters
                {
                    ParameterName = "@WaybillID",
                    ParameterValue = waybill.WaybillID.ToString()
                }
            };

            _database.ModifyDatabase(baseCommand, parameters);

            _database.CloseConnection();

            return true;
        }

        public IEnumerable<DataModel.WaybillListModel> GetWaybills()
        {
            List<DataModel.WaybillListModel> waybills = new List<DataModel.WaybillListModel>();

            string baseCommand = "select * from waybills inner join vehicle on vhid=wbassignedvehicle";
            List<Parameters> parameters = new List<Parameters>();
            

            SqlDataReader reader = _database.ReadData(baseCommand, parameters);

            if (reader.HasRows)
            {

                while (reader.Read())
                {
                    waybills.Add(new DataModel.WaybillListModel()
                    {
                            WaybillID = reader.GetInt32(reader.GetOrdinal("wbid")),
                            TotalWeight = reader.GetDecimal(reader.GetOrdinal("wbtotalweight")),
                            TotalParcels = reader.GetInt32(reader.GetOrdinal("wbtotalparcels")),
                            AssignedVehicle = reader.GetInt32(reader.GetOrdinal("wbassignedvehicle")),
                            VehicleDescription = reader.GetString(reader.GetOrdinal("vhdescription"))
                    });
                }
               
            }

            reader.Close();
            _database.CloseConnection();

            return waybills;

        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using TritonMVC.Interfaces;
using TritonMVC.Services;


namespace TritonMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchApiController : ControllerBase
    {
        private readonly Interfaces.IDatabase _database;

        public BranchApiController(Interfaces.IDatabase Database)
        {
            _database = Database;
        }


        [Route("[action]")]
        [HttpGet]

        public IEnumerable<DataModel.BranchDataModel.BranchMaster> GetAllBranches()
        {

            IBranch branchService = new Branch(_database);

            return branchService.GetBranches();
        }

        [Route("[action]/{ID}")]
        [HttpGet]

        public DataModel.BranchDataModel.BranchMaster GetBranchByID(int ID)
        {
            IBranch branchService = new Branch(_database);

            return branchService.GetBranchByID(ID);
        }


        [Route("[action]")]
        [HttpPost]

        public HttpResponseMessage UpdateBranchDetail([FromBody] DataModel.BranchDataModel.BranchMaster BranchData )
        {
            string baseCommand = @"update branch set brname=@branchName where brid=@branchID";
            List<Services.Parameters> parameters = new List<Services.Parameters>();
            parameters.Add(new Services.Parameters()
            {
                ParameterName = "@branchName",
                ParameterValue = BranchData.BranchName
            });
            parameters.Add(new Services.Parameters()
            {
                ParameterName = "@branchID",
                ParameterValue = BranchData.BranchID.ToString()
            });

            _database.ModifyDatabase(baseCommand, parameters);

            _database.CloseConnection();

            return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);

        }

        [Route("[action]")]
        [HttpPost]

        public HttpResponseMessage InsertNewBranch([FromBody] DataModel.BranchDataModel.BranchMaster BranchData)
        {

            Branch branch = new Branch(_database);

            branch.Insert(BranchData);

            return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);

        }
    }

   
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace TritonMVC.Controllers
{
    
    public class BranchController : Controller
    {
        private readonly IHttpClientFactory _clientFactory;

        public BranchController(IHttpClientFactory  clientFactory)
        {
            _clientFactory = clientFactory;
        }

        // GET: BranchController
        public ActionResult Index()
        {
            List<Models.BranchModel> branches = new List<Models.BranchModel>(); 
            //List Of the Branches
            //string APIUrl = "http://localhost:5072/api/BranchAPI/GetAllBranches/";
            var client = _clientFactory.CreateClient("tritonapi");
            

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "BranchAPI/GetAllBranches/").Result;

            if (response.IsSuccessStatusCode)
            {
                branches = JsonConvert.DeserializeObject<List<Models.BranchModel>>(response.Content.ReadAsStringAsync().Result);                
            }

            return View(branches);
        }

        // GET: BranchController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: BranchController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BranchController/Edit/5
        public ActionResult Edit(int id)
        {
            Models.BranchModel branch = new Models.BranchModel();

            var client = _clientFactory.CreateClient("tritonapi");

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "branchapi/getbranchbyid/" + id).Result;

            if (response.IsSuccessStatusCode)
            {
                branch = JsonConvert.DeserializeObject<Models.BranchModel>(response.Content.ReadAsStringAsync().Result);
            }


            return View(branch);
        }

        // POST: BranchController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveBranch(Models.BranchModel form)
        {
            try
            {

                var client = _clientFactory.CreateClient("tritonapi");
                

                var json = JsonConvert.SerializeObject(form,Formatting.None);
                var data = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                
                var response = client.PostAsync(client.BaseAddress + "branchapi/updatebranchdetail/",data).Result;
                return RedirectToAction(nameof(Index));
                

            }
            catch
            {
                return View(Index);
            }
        }

        // GET: BranchController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: BranchController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult New()
        {
            return View();
        }

        public ActionResult InsertBranch(Models.BranchModel form)
        {
            var client = _clientFactory.CreateClient("tritonapi");


            var json = JsonConvert.SerializeObject(form, Formatting.None);
            var data = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


            var response = client.PostAsync(client.BaseAddress + "branchapi/insertnewbranch/", data).Result;

            return RedirectToAction(nameof(Index));
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using TritonMVC.Interfaces;
using TritonMVC.Services;

namespace TritonMVC.Controllers
{
    

    public class VehicleController : Controller
    {

        private readonly IHttpClientFactory _clientFactory;
        private readonly IDatabase _database;


        public VehicleController(IHttpClientFactory clientFactory, IDatabase database)
        {
            _clientFactory = clientFactory;
            _database = database;
        }

        public IActionResult Index()
        {
            List<Models.VehicleListModel> vehicles = new List<Models.VehicleListModel>();

            var client = _clientFactory.CreateClient("tritonapi");
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "vehicleapi/GetVehicleList/").Result;

            if (response.IsSuccessStatusCode)
            {
                vehicles = JsonConvert.DeserializeObject<List<Models.VehicleListModel>>(response.Content.ReadAsStringAsync().Result);
            }

            return View(vehicles);
        }

        public IActionResult EditVehicle(int ID)
        {
            Models.VehicleModel vehicleModel = new Models.VehicleModel();

            var client = _clientFactory.CreateClient("tritonapi");
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "vehicleapi/getvehiclebyid/" + ID.ToString()).Result;

            if (response.IsSuccessStatusCode)
            {
                vehicleModel = JsonConvert.DeserializeObject<Models.VehicleModel>(response.Content.ReadAsStringAsync().Result);
            }

            List<SelectListItem> vehicleTypes = new List<SelectListItem>()
            {
                new SelectListItem()
                {
                    Value="N/A",
                    Text = "-- Select a Vehicle Type --"
                },
                new SelectListItem()
                {
                    Value="Horse",
                    Text = "Horse"
                },
                new SelectListItem()
                {
                    Value="12 Metre Trailer",
                    Text = "12 Metre Trailer"
                },
                new SelectListItem()
                {
                    Value="6 Metre Trailer",
                    Text = "6 Metre Trailer"
                }
            };

            //Load the list of Branches
            IBranch branchService = new Branch(_database);


            ViewData["BranchList"] = new SelectList(branchService.GetBranches(), "BranchID", "BranchName");
            ViewData["vehicleTypes"] = vehicleTypes;

            return View(vehicleModel);
        }

        public IActionResult SaveVehicle(Models.VehicleModel vehicleForm)
        {
            try
            {

                var client = _clientFactory.CreateClient("tritonapi");


                var json = JsonConvert.SerializeObject(vehicleForm, Formatting.None);
                var data = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


                var response = client.PostAsync(client.BaseAddress + "vehicleapi/savevehicle/", data).Result;
                return RedirectToAction(nameof(Index));


            }
            catch
            {
                return View(Index);
            }
        }

        public IActionResult Insertvehicle(Models.VehicleModel vehicleForm)
        {
            try
            {

                var client = _clientFactory.CreateClient("tritonapi");


                var json = JsonConvert.SerializeObject(vehicleForm, Formatting.None);
                var data = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


                var response = client.PostAsync(client.BaseAddress + "vehicleapi/InsertVehicle/", data).Result;

                return RedirectToAction(nameof(Index));


            }
            catch
            {
                return View(Index);
            }

            
        }

        public IActionResult NewVehicle()
        {
            Models.VehicleModel vehicleModel = new Models.VehicleModel();

            var client = _clientFactory.CreateClient("tritonapi");
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "vehicleapi/getvehiclebyid/").Result;


            List<SelectListItem> vehicleTypes = new List<SelectListItem>()
            {
                new SelectListItem()
                {
                    Value="N/A",
                    Text = "-- Select a Vehicle Type --"
                },
                new SelectListItem()
                {
                    Value="Horse",
                    Text = "Horse"
                },
                new SelectListItem()
                {
                    Value="12 Metre Trailer",
                    Text = "12 Metre Trailer"
                },
                new SelectListItem()
                {
                    Value="6 Metre Trailer",
                    Text = "6 Metre Trailer"
                }
            };

            //Load the list of Branches
            IBranch branchService = new Branch(_database);

            ViewData["BranchList"] = new SelectList(branchService.GetBranches(), "BranchID", "BranchName");
            ViewData["vehicleTypes"] = vehicleTypes;

            return View(vehicleModel);
        }


    }
}

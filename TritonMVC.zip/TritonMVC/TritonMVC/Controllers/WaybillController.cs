﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;

namespace TritonMVC.Controllers
{
    public class WaybillController : Controller
    {
        public readonly IHttpClientFactory _clientFactory;

        public WaybillController(IHttpClientFactory httpClient)
        {
            _clientFactory = httpClient;
        }
        public IActionResult Index()
        {
            List<Models.WaybillListModel> waybills = new List<Models.WaybillListModel>();
            var client = _clientFactory.CreateClient("tritonapi");
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "waybillapi/getwaybills/").Result;

            if (response.IsSuccessStatusCode)
            {
                waybills = JsonConvert.DeserializeObject<List<Models.WaybillListModel>>(response.Content.ReadAsStringAsync().Result);
            }
           
            return View(waybills);
        }

        public IActionResult EditWaybill(int ID)
        {
            Models.WaybillModel waybills = new Models.WaybillModel();
            List<Models.VehicleListModel> vehicles = new List<Models.VehicleListModel>();


            var client = _clientFactory.CreateClient("tritonapi");
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "waybillapi/getwaybillbyid/" + ID).Result;

            if (response.IsSuccessStatusCode)
            {
                waybills = JsonConvert.DeserializeObject<Models.WaybillModel>(response.Content.ReadAsStringAsync().Result);
            }

            HttpResponseMessage vehicleResponse = client.GetAsync(client.BaseAddress + "vehicleapi/GetVehicleList/").Result;

            if (vehicleResponse.IsSuccessStatusCode)
            {
                vehicles = JsonConvert.DeserializeObject<List<Models.VehicleListModel>>(vehicleResponse.Content.ReadAsStringAsync().Result);
                ViewData["VehicleList"] = new SelectList(vehicles, "VehicleID", "Description");
            }

            return View(waybills);

        }

        public IActionResult SaveWaybill(Models.WaybillModel waybillForm)
        {
            var client = _clientFactory.CreateClient("tritonapi");


            var json = JsonConvert.SerializeObject(waybillForm, Formatting.None);
            var data = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


            var response = client.PostAsync(client.BaseAddress + "waybillapi/savewaybill/", data).Result;
            return RedirectToAction(nameof(Index));

        }

        public IActionResult NewWayBill()
        {
            List<Models.VehicleListModel> vehicles = new List<Models.VehicleListModel>();

            var client = _clientFactory.CreateClient("tritonapi");
            HttpResponseMessage vehicleResponse = client.GetAsync(client.BaseAddress + "vehicleapi/GetVehicleList/").Result;

            if (vehicleResponse.IsSuccessStatusCode)
            {
                vehicles = JsonConvert.DeserializeObject<List<Models.VehicleListModel>>(vehicleResponse.Content.ReadAsStringAsync().Result);
                ViewData["VehicleList"] = new SelectList(vehicles, "VehicleID", "Description");
            }

            Models.WaybillModel waybill = new Models.WaybillModel();

            return View(waybill);
        }

        public IActionResult Insert(Models.WaybillModel waybillForm)
        {
            var client = _clientFactory.CreateClient("tritonapi");


            var json = JsonConvert.SerializeObject(waybillForm, Formatting.None);
            var data = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


            var response = client.PostAsync(client.BaseAddress + "waybillapi/insertwaybill/", data).Result;
            return RedirectToAction(nameof(Index));
        }


    }
}

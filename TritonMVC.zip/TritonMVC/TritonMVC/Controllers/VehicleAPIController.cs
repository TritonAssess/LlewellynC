﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using TritonMVC.Interfaces;
using TritonMVC.Services;

namespace TritonMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleAPIController : ControllerBase
    {
        private readonly IDatabase _database;

        public VehicleAPIController(IDatabase Database)
        {
            _database = Database;
        }

        [Route("[action]/{ID}")]
        [HttpGet]

        public DataModel.VehicleDataModel GetVehicleByID(int ID)
        {
            DataModel.VehicleDataModel vehicleDataModel = new DataModel.VehicleDataModel();

            string baseCommand = "select * from vehicle  where vhid=@ID";

            List<Services.Parameters> parameters = new List<Services.Parameters>();

            parameters.Add(new Services.Parameters()
            {
                ParameterName = "@ID",
                ParameterValue = ID.ToString()
            });

            SqlDataReader reader = _database.ReadData(baseCommand, parameters);

            if (reader.HasRows)
            {
                reader.Read();
                vehicleDataModel.VehicleID = reader.GetInt32(reader.GetOrdinal("vhid"));
                vehicleDataModel.Type = reader.GetString(reader.GetOrdinal("vhtype"));
                vehicleDataModel.Description = reader.GetString(reader.GetOrdinal("vhdescription"));
                vehicleDataModel.VinNumber = reader.GetString(reader.GetOrdinal("vhvinnumber"));
                vehicleDataModel.NumberPlate = reader.GetString(reader.GetOrdinal("vhnumberplate"));

            }

            reader.Close();
            _database.CloseConnection();

            return vehicleDataModel;
        }

        [Route("[action]")]
        [HttpPost]

        public string SaveVehicle([FromBody] DataModel.VehicleDataModel vehicle)
        {
            string baseCommand = @"update vehicle set vhtype=@Type,
                                   vhdescription=@Description,
                                   vhvinnumber=@VinNumber,
                                   vhnumberplate=@NumberPlate,
                                   vhbranchid=@BranchID
                                   where vhid=@ID";

            List<Services.Parameters> parameters = new List<Services.Parameters>()
            {
                new Services.Parameters
                {
                    ParameterName="@Type",
                    ParameterValue=vehicle.Type
                },
                new Services.Parameters
                {
                    ParameterName="@Description",
                    ParameterValue=vehicle.Description
                },
                new Services.Parameters
                {
                    ParameterName="@VinNumber",
                    ParameterValue=vehicle.VinNumber
                },
                new Services.Parameters
                {
                    ParameterName="@NumberPlate",
                    ParameterValue=vehicle.NumberPlate
                },
                new Services.Parameters
                {
                    ParameterName="@ID",
                    ParameterValue=vehicle.VehicleID.ToString()
                },
                new Services.Parameters
                {
                    ParameterName="@BranchID",
                    ParameterValue=vehicle.BranchID.ToString()
                }
            };

            _database.ModifyDatabase(baseCommand, parameters);

            _database.CloseConnection();

            return "Success";
        }

        [Route("[action]")]
        [HttpGet]
        public IEnumerable<DataModel.VehicleListDataModel> GetVehicleList()
        {
            IVehicle vehicle = new Vehicle(_database);

            return vehicle.GetList();
        }

        [Route("[action]")]
        [HttpPost]

        public bool InsertVehicle(DataModel.VehicleDataModel vehicleModel)
        {
            IVehicle vehicle = new Vehicle(_database);

            return vehicle.Insert(vehicleModel);
        }






    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TritonMVC.Interfaces;
using TritonMVC.Services;

namespace TritonMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WaybillAPIController : ControllerBase
    {
        
        [Route("[action]/{ID}")]
        [HttpGet]

        public DataModel.WaybillListModel GetWaybillByID(int ID)
        {
            IWaybill waybill = new Waybill(new Database());

            return waybill.GetWayBillByID(ID);
        }

        [Route("[action]")]
        [HttpPost]
        public string SaveWaybill([FromBody] DataModel.WaybillModel waybillData)
        {
            IWaybill waybill = new Waybill(new Database());
            waybill.Update(waybillData);

            return "Success";
        }

        [Route("[action]")]
        [HttpPost]
        public string InsertWaybill([FromBody] DataModel.WaybillListModel waybillData)
        {
            IWaybill waybill = new Waybill(new Database());
            waybill.Insert(waybillData);

            return "Success";
        }

        [Route("[action]")]
        [HttpGet]

        public IEnumerable<DataModel.WaybillListModel> GetWaybills()
        {
            IWaybill waybill = new Waybill(new Database());

            return waybill.GetWaybills();
        }

    }
}
